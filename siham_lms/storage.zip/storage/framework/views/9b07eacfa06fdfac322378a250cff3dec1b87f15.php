<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="body_bg">
    <!-- Header Start -->

    <!-- Header End -->

    <body class="innerpages body_bg">
        <!-- Header Start -->
        <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <!-- Header End -->

        <!-- innerBanner start -->
        <div class="innerBanner">
            <img src="images/Bannar-3.jpg" class="img-responsive" alt="courses-Banner">
            <div class="innerBannerOverlay">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12 centerCol">
                        <h1>Online Classes</h1>
                    </div>
                </div>
            </div>
        </div>
        <!-- innerBanner end -->

        <div class="clear"></div>

        <!-- Saying-section -->
        <div class="Saying_section online_classes">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-sm-10 col-xs-12 center">
                        <div class="startLearning_head">
                            <h2 data-aos="fade-down">Online Classes</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="row">
                        <?php $__currentLoopData = $home_page_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videosfront): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="video_box" data-aos="fade-up" data-aos-delay="300">
                                <div class="video_boxImg">
                                    <img src="<?php echo e(URL::asset('uploadsVideoImage/'.$videosfront->photo)); ?>" alt="img">
                                    <div class="video_boxImgOverlay">
                                        <a data-fancybox="gallery" href="<?php echo e($videosfront->youtubeurl); ?>"><img src="images/paly-icon.png" alt="img"></a>
                                    </div>
                                </div>
                                <div class="video_boxText">
                                    <p><?php echo e($videosfront->content); ?></p>
                                    <a class="btn_pink2"><?php echo e($videosfront->name); ?></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>


                </div>
            </div>
        </div>
        <!-- Saying-section -->



        <!--Footer Content Start-->
        <!--Footer Content Start-->
        <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Js Files Start -->
        <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
        <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    </body>

</html><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/frontend/onlineClasses.blade.php ENDPATH**/ ?>