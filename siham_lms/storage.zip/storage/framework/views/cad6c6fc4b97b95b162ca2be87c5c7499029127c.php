<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="innerpages body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Header End -->
    <!-- innerBanner start -->
    <div class="innerBanner">

        <?php if($course_header_image == null): ?>
            <img src="<?php echo e(asset('images/Bannar-3.jpg')); ?>" class="img-responsive" alt="courses-Banner">
        <?php endif; ?>
        <?php if($course_header_image != null): ?>
            <img src="<?php echo e(url('/siham_lms/storage/app/public/'.$course_header_image	)); ?>"  class="img-responsive" alt="courses-Banner">
        <?php endif; ?>

      <div class="innerBannerOverlay">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12 centerCol">
            <h1>Courses</h1>
          </div>
        </div>
      </div>
    </div>
    <!-- innerBanner end -->
    <div class="clear"></div>
    <!--startLearning-section -->
    <div class="startLearning_section padding_both">
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-sm-10 col-xs-12 center">
            <div class="startLearning_head wow bounceInDown" data-wow-delay="0.6s" data-wow-duration="2s">
              <h2 data-aos="fade-down">Courses We Offer </h2>
              <p data-aos="fade-down">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisl eros, pulvinar facilisis justo mollis, auctor consequat urna. Morbi a bibendum metus..</p>
            </div>
          </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="subjctListBox body_bg">
              <h2> <?php echo e($subject->name); ?></h2>
              <div id="scrolWrapper">
                <div class="scrollbar" id="style-2">
                  <ul class="subject-list">

                    <?php $__currentLoopData = $frontCources->where('course_id', $subject->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li> <?php echo e($cource->content); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
    <!-- startLearning-section -->

    <!--Footer Content Start-->
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/frontend/courses.blade.php ENDPATH**/ ?>