
<?php $__env->startSection('page_title', 'Manage Complains'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Manage Complains</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#all-classes" class="nav-link active" data-toggle="tab">Manage Complains</a></li>
                <li class="nav-item"><a href="#new-class" class="nav-link" data-toggle="tab"><i class="icon-plus2"></i> Create New Complains</a></li>
            </ul>

            <div class="tab-content">
                    <div class="tab-pane fade show active" id="all-classes">
                        <table class="table datatable-button-html5-columns">
                            <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Student Name</th>
                                <th>Emails</th>
                                <th>Subject</th>
                                <th>Cell</th>

                                <th>Status</th>

                                <?php if(Qs::userIsTeamSA()): ?>

                                <?php endif; ?>


                                     <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php $__currentLoopData = $fetchapplication; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fetch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($fetch->users->name); ?></td>
                                    <td><?php echo e($fetch->email); ?></td>
                                    <td><?php echo e($fetch->subject); ?></td>
                                    <td><?php echo e($fetch->cell); ?></td>

                                    <?php if($fetch->status == 0 ): ?>
                                        <td>Pending</td>
                                    <?php elseif($fetch->status == 1 ): ?>
                                        <td>Responded</td>
                                    <?php endif; ?>

                                    <?php if(Qs::userIsTeamSA()): ?>




                                    <?php endif; ?>
                                    <td class="text-center">
                                        <div class="list-icons">
                                            <div class="dropdown">
                                                <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                    <i class="icon-menu9"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-left">
                                                    <?php if(Qs::userIsTeamSA()): ?>
                                                    <a href="<?php echo e(route('application.manage_complain',Qs::hash($fetch->id))); ?>" class="dropdown-item"><i class="icon-add"></i> Add Response</a>
                                                   <?php endif; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                <div class="tab-pane fade" id="new-class">
                    <div class="row">
                        <div class="col-md-12">





                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <form enctype="multipart/form-data"  method="post" action="<?php echo e(route('students.general_app_storeComplains')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>


                                <div class="form-group row">
                                    <label for="class_type_id" class="col-lg-3 col-form-label font-weight-semibold">To: </label>
                                    <div class="col-lg-9">
                                        <select required data-placeholder="Select Class Type" class="form-control select" name="std_id" id="class_type_id">
                                            <option selected disabled value="">--- Select Any ---</option>
                                            <option>HR</option>
                                            <option>Admin</option>
                                            <option>Faculty</option>
                                            <option>Student Relation</option>
                                            <option>Accounts</option>
                                            <option>Examination</option>
                                            <option>Others</option>




                                        </select>
                                    </div>
                                </div>
                         </div>
                        <div class="col-md-6">

                                <div class="form-group row">
                                    <label for="class_type_id" class="col-lg-3 col-form-label font-weight-semibold">Email</label>
                                    <div class="col-lg-9">
                                        <input name="email" required type="text" class="form-control" placeholder="Email">
                                        




                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label for="class_type_id" class="col-lg-3 col-form-label font-weight-semibold">Subject</label>
                                    <div class="col-lg-9">

                                        <select required data-placeholder="Select Subject" class="form-control select" name="subject" id="class_type_id">
                                            
                                            <option selected disabled value="">--- Select Any ---</option>
                                            <option>Course Registration</option>
                                            <option>Course Drop</option>
                                            <option>Semester Drop</option>
                                            <option>Other</option>





                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">

                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold">Cell <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input type="number" name="cell" required type="text" class="form-control" placeholder="Cell number">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold">attechemt <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input type="file" name="photo"  required type="text" class="form-control" >
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <label class="col-lg-2 col-form-label font-weight-semibold">Application <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                       <textarea class="form" cols="50" rows="5" name="application"></textarea>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="text-right">
                                    <button id="ajax-btn" type="submit" class="btn btn-primary">Submit form <i class="icon-paperplane ml-2"></i></button>
                                </div>
                            </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/applications/dropComplain.blade.php ENDPATH**/ ?>