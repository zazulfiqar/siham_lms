<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta id="csrf-token" name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="author" content="CJ Inspired">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.min.css')); ?>" type="text/css">


<link href=" <?php echo e(asset('assets/css/qs.css')); ?>" rel="stylesheet" type="text/css">


    <script src="<?php echo e(asset('global_assets/js/main/jquery.min.js')); ?> "></script>
    <script src="<?php echo e(asset('global_assets/js/main/bootstrap.bundle.min.js')); ?> "></script>
    <script src="<?php echo e(asset('global_assets/js/plugins/loaders/blockui.min.js')); ?> "></script>
    <title> <?php echo $__env->yieldContent('page_title'); ?> | <?php echo e(config('app.name')); ?> </title>


</head>

<?php echo $__env->make('partials.inc_bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>



<body class="innerpages body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


    <div class="innerBanner">
        <img src="<?php echo e(asset('images/Bannar-1.jpg')); ?>" class="img-responsive" alt="courses-Banner">
        <div class="innerBannerOverlay">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12 centerCol">
              <h1>Register</h1>
            </div>
          </div>
        </div>
      </div>

      <div class="register_section">
        <div class="container">
          <div class="row">
            <div class="col-md-9 col-sm-9 col-xs-12 center">
              <div class="login_popup">
                <div class="login_popupForm">
                  <h2 data-aos="fade-down">Register  Now</h2>
                  <P data-aos="fade-down">Choose from 130,000 online video courses with new additions published every month</P>


                  <form id="" method="post" enctype="multipart/form-data" class="wizard-form steps-validation"
                  action="<?php echo e(route('teachers.store')); ?>" data-fouc>
            <?php echo csrf_field(); ?>

            <fieldset>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Full Name: <span class="text-danger">*</span></label>
                            <input value="<?php echo e(old('name')); ?>" required type="text" name="name" placeholder="Full Name"
                                   class="form-control">
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Address: <span class="text-danger">*</span></label>
                            <input value="<?php echo e(old('address')); ?>" class="form-control" placeholder="Address"
                                   name="address" type="text" required>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Email address: </label>
                            <input type="email" value="<?php echo e(old('email')); ?>" name="email" class="form-control"
                                   placeholder="Email Address">
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="gender">Gender: <span class="text-danger">*</span></label>
                            <select class="selectBoxFront select form-control" id="gender" name="gender" required data-fouc
                                    data-placeholder="Choose..">
                                <option value="">Choose Gender</option>
                                <option <?php echo e((old('gender') == 'Male') ? 'selected' : ''); ?> value="Male">Male</option>
                                <option <?php echo e((old('gender') == 'Female') ? 'selected' : ''); ?> value="Female">Female
                                </option>
                            </select>
                        </div>
                    </div>

                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    

                </div>

                <div class="row">
                    
                    
                    
                    

                    
                    

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="nal_id">Nationality: <span class="text-danger">*</span></label>
                            <select data-placeholder="Choose..." required name="nal_id" id="nal_id"
                                    class="selectBoxFront select-search form-control">
                                <option value="">Choose Nationality</option>
                                <?php $__currentLoopData = $nationals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        <?php echo e((old('nal_id') == $nal->id ? 'selected' : '')); ?> value="<?php echo e($nal->id); ?>"><?php echo e($nal->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <label for="state_id">State: <span class="text-danger">*</span></label>
                        <select onchange="getLGA(this.value)" required data-placeholder="Choose.."
                                class="selectBoxFront select-search form-control" name="state_id" id="state_id">
                            <option value="">Choose State</option>
                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    <?php echo e((old('state_id') == $st->id ? 'selected' : '')); ?> value="<?php echo e($st->id); ?>"><?php echo e($st->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>



                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <label for="lga_id">LGA: <span class="text-danger">*</span></label>
                        <select  required data-placeholder="Select State First" class="selectBoxFront select-search form-control"
                                name="lga_id" id="lga_id">
                            <option value=""> Choose LGA</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <br>
                        <div class="form-group">
                            <label class="d-block">Upload Passport Photo:</label>
                            <input  value="<?php echo e(old('photo')); ?>" accept="image/*" type="file" name="photo"
                                   class="form-input-styled" data-fouc>
                            <span class="form-text text-muted">Accepted Images: jpeg, png. Max file size 2Mb</span>
                        </div>
                    </div>
                </div>

            </fieldset>


            <fieldset>
                <div class="row">








































                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="year_admitted">joining Date / Admitted: <span class="text-danger">*</span></label>
                            <select data-placeholder="Choose..." required name="year_admitted" id="year_admitted"
                                    class="selectBoxFront select-search form-control">
                                <option value=""> Choose joining Date / Admitted</option>
                                <?php for($y=date('Y', strtotime('- 10 years')); $y<=date('Y'); $y++): ?>
                                    <option
                                        <?php echo e((old('year_admitted') == $y) ? 'selected' : ''); ?> value="<?php echo e($y); ?>"><?php echo e($y); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    
                    
                    
                    
                    
                    
                    
                    

                    

                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    

                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Age:</label>
                            <input min="1" type="number" name="age" placeholder="Age" class="form-control selectBoxFront"
                                   value="<?php echo e(old('age')); ?>">
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Teaching Speciality:</label>
                            <input  type="teaching_speciality" name="teaching_speciality" placeholder="teaching_speciality" class="selectBoxFront form-control"
                                   value="<?php echo e(old('teaching_speciality')); ?>">
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12" data-aos="fade-up" data-aos-delay="600">
                  <input type="submit" value="Register Now">
                </div>
              </div>

    </div>
  </div>
</div>
</div>
</div>
</div>

        </form>
    </div>
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>



<?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/frontend/teacherAdd.blade.php ENDPATH**/ ?>