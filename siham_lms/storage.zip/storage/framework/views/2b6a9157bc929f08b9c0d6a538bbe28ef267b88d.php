
<?php $__env->startSection('page_title', 'Manage Courses'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Edit Courses</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#new-course" class="nav-link active" data-toggle="tab">Add Course</a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane show  active fade" id="new-course">
                    <div class="row">
                        <div class="col-md-6">
                            
                            <form class="" method="post" action="<?php echo e(route('courses.update',$course->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>


                                <div class="form-group row">
                                    <label for="type" class="col-lg-3 col-form-label font-weight-semibold">Select
                                        Course Type <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select required class="form-control select"
                                                name="type" id="type">
                                                <option
                                                    <?php echo e($course->type == 0  ? 'selected' : ''); ?> value="0">General</option>
                                                <option
                                                    <?php echo e($course->type == 1  ? 'selected' : ''); ?> value="1">Private</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Course Name
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="name" name="name" value="<?php echo e($course->name); ?>" required type="text"
                                               class="form-control" placeholder="Name of Course">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Course Code
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="code" name="code" value="<?php echo e($course->code); ?>" required type="text"
                                               class="form-control" placeholder="Course Code">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Course
                                        Description <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="description" name="description" value="<?php echo e($course->description); ?>"
                                               required type="text" class="form-control"
                                               placeholder="Course Description">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">Select
                                        Class <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select required class="form-control select"
                                                name="my_class_id" id="my_class_id">
                                            <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    <?php echo e($c->id == $course->my_class_id  ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">

                                    <label for="teacher_id" class="col-lg-3 col-form-label font-weight-semibold">Teacher
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select required data-placeholder="Select Teacher"
                                                class="form-control select-search" name="teacher_id" id="teacher_id">
                                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    <?php echo e($course->teacher_id == Qs::hash($t->id) ? 'selected' : ''); ?> value="<?php echo e(Qs::hash($t->id)); ?>"><?php echo e($t->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Time Slot
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="time_slot" name="time_slot" value="<?php echo e($course->time_slot); ?>" required
                                               type="text" class="form-control" placeholder="Time Slot">
                                    </div>
                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Submit form <i
                                            class="icon-paperplane ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/courses/edit.blade.php ENDPATH**/ ?>