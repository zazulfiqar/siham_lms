
<?php $__env->startSection('page_title', 'Student Profile - '.$tech->user->name); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-3 text-center">
        <div class="card">
            <div class="card-body">

                <img style="width: 90%; height:90%" src="<?php echo e(url('/siham_lms/storage/app/public/'.$tech->user->photo	)); ?>" alt="photo" class="rounded-circle">
                <br>
                <h3 class="mt-3"><?php echo e($tech->user->name); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-9">
        <div class="card">
            <div class="card-body">
                <ul class="nav nav-tabs nav-tabs-highlight">
                    <li class="nav-item">
                        <a href="#" class="nav-link active"><?php echo e($tech->user->name); ?></a>
                    </li>
                </ul>

                <div class="tab-content">
                    
                    <div class="tab-pane fade show active" id="basic-info">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <td class="font-weight-bold">Name</td>
                                <td><?php echo e($tech->user->name); ?></td>
                            </tr>
                            

                            
                            
                            
                            <tr>
                                <td class="font-weight-bold">Gender</td>
                                <td><?php echo e($tech->user->gender); ?></td>
                            </tr>
                            <tr>
                                <td class="font-weight-bold">Address</td>
                                <td><?php echo e($tech->user->address); ?></td>
                            </tr>
                            <?php if($tech->user->email): ?>
                            <tr>
                                <td class="font-weight-bold">Email</td>
                                <td><?php echo e($tech->user->email); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($tech->user->phone): ?>
                                <tr>
                                    <td class="font-weight-bold">Phone</td>
                                    <td><?php echo e($tech->user->phone.' '.$tech->user->phone2); ?></td>
                                </tr>
                            <?php endif; ?>




                            
                            <?php if($tech->user->nal_id): ?>
                            <tr>
                                <td class="font-weight-bold">Nationality</td>
                                <td><?php echo e($tech->user->nationality->name); ?></td>
                            </tr>
                            <?php endif; ?>







                            
                            
                            

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/teachers/show.blade.php ENDPATH**/ ?>