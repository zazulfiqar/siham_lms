<div class="sidebar sidebar-dark sidebar-main sidebar-expand-md">

    <!-- Sidebar mobile toggler -->
    <div class="sidebar-mobile-toggler text-center">
        <a href="#" class="sidebar-mobile-main-toggle">
            <i class="icon-arrow-left8"></i>
        </a>
        Navigation
        <a href="#" class="sidebar-mobile-expand">
            <i class="icon-screen-full"></i>
            <i class="icon-screen-normal"></i>
        </a>
    </div>
    <!-- /sidebar mobile toggler -->

    <!-- Sidebar content -->
    <div class="sidebar-content">

        <!-- User menu -->
        <div class="sidebar-user">
            <div class="card-body">
                <div class="media">
                    <div class="mr-3">
                        <a href="<?php echo e(route('my_account')); ?>">

                            <?php if(isset(Auth::user()->photo)): ?>
                                <img src="<?php echo e(url('/siham_lms/storage/app/public/'.Auth::user()->photo	)); ?>" width="38" height="38"
                                     class="rounded-circle" alt="photo">
                            <?php endif; ?>
                        </a>
                    </div>

                    <div class="media-body">
                        <?php if(isset(Auth::user()->name)): ?>
                        <div class="media-title font-weight-semibold"><?php echo e(Auth::user()->name); ?></div>
                        <?php endif; ?>
                        <div class="font-size-xs opacity-50">
                            <i class="icon-user font-size-sm"></i> <?php if(isset(Auth::user()->user_type)): ?> &nbsp;<?php echo e(ucwords(str_replace('_', ' ', Auth::user()->user_type))); ?> <?php endif; ?>
                        </div>
                    </div>

                    <div class="ml-3 align-self-center">
                        <a href="<?php echo e(route('my_account')); ?>" class="setting"><i class="icon-cog3"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /user menu -->

        <!-- Main navigation -->
        <div class="card card-sidebar-mobile">
            <ul class="nav nav-sidebar" data-nav-type="accordion">

                <!-- Main -->
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e((Route::is('dashboard')) ? 'active' : ''); ?>">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                            
                <?php if(Qs::userIsAdministrative()): ?>
                <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.create', 'payments.invoice', 'payments.receipts', 'payments.edit', 'payments.manage', 'payments.show',]) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                    <a href="#" class="nav-link"><i class="icon-office"></i> <span> Administrative</span></a>

                    <ul class="nav nav-group-sub" data-submenu-title="Administrative">

                         <?php if(Qs::userIsTeamAccount()): ?>
                        <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.create', 'payments.edit', 'payments.manage', 'payments.show', 'payments.invoice']) ? 'nav-item-expanded' : ''); ?>">

                            <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.edit', 'payments.create', 'payments.manage', 'payments.show', 'payments.invoice']) ? 'active' : ''); ?>"><i
                                            class="fa fa-money" aria-hidden="true"></i>Payments</a>

                            <ul class="nav nav-group-sub">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('payments.create')); ?>" class="nav-link <?php echo e(Route::is('payments.create') ? 'active' : ''); ?>">
                                        <i class="fa fa-money" aria-hidden="true"></i>Create Payment
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('payments.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['payments.index', 'payments.edit', 'payments.show']) ? 'active' : ''); ?>">
                                        <i class="fa fa-list" aria-hidden="true"></i>Manage Payments
                                    </a>
                                </li>
                                 
                                        

                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>

                <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                    <a href="#" class="nav-link"><i class="icon-users"></i> <span> Users</span></a>

                    <ul class="nav nav-group-sub" data-submenu-title="Manage Students">
                        <?php if(Qs::userIsTeamSA()): ?>
                        <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                            <a href="#" class="nav-link"><i class="icon-users"></i> <span> Students</span></a>

                            <ul class="nav nav-group-sub" data-submenu-title="Students">
                                <li class="nav-item">

                                    <a href="<?php echo e(route('status.inactive_students')); ?>" class="nav-link <?php echo e((Route::is('status.inactive_students')) ? 'active' : ''); ?>">
                                        <i class="fa fa-ban"></i>Inactive Student</a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('status.active_students')); ?>" class="nav-link <?php echo e((Route::is('status.active_students')) ? 'active' : ''); ?>">

                                        <i class="fa fa-check"></i>Active Student</a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('students.create')); ?>" class="nav-link <?php echo e((Route::is('students.create')) ? 'active' : ''); ?>">
                                        <i class="fa fa-plus"></i>Add New Student</a>
                                </li>

                            </ul>
                        </li>
                        <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>
                        <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                            <a href="#" class="nav-link"><i class="icon-users"></i> <span>Teachers</span></a>
                            <ul class="nav nav-group-sub" data-submenu-title="Manage Teachers">
                                <!--<li class="nav-item">-->
                                <a href="<?php echo e(route('status.inactive_teachers')); ?>" class="nav-link <?php echo e((Route::is('status.inactive_teachers')) ? 'active' : ''); ?>">
                                    <i class="fa fa-ban"></i>Inactive Teacher</a>
                                <!--</li>-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('status.active_teachers')); ?>" class="nav-link <?php echo e((Route::is('status.active_teachers')) ? 'active' : ''); ?>">
                                        <i class="fa fa-check"></i>Active Teacher</a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('teachers.create')); ?>" class="nav-link <?php echo e((Route::is('teachers.create')) ? 'active' : ''); ?>">
                                        <i class="fa fa-plus"></i>Add New Teacher
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>          <?php endif; ?>

                    </ul>
                </li>
                <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>

                <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                    <a href="#" class="nav-link"><i class="fa fa-university"></i> <span> Classes & Sections </span></a>

                    <ul class="nav nav-group-sub" data-submenu-title="Manage Students">
                         
                        <li class="nav-item">
                            <a href="<?php echo e(route('classes.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['classes.index','classes.edit']) ? 'active' : ''); ?>"><i
                                        class="icon-windows2"></i> <span> Classes</span></a>
                        </li>

                        
                        <li class="nav-item">
                            <a href="<?php echo e(route('sections.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['sections.index','sections.edit',]) ? 'active' : ''); ?>"><i
                                        class="icon-fence"></i> <span>Sections</span></a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>    



                <li class="nav-item">
                    <a href="<?php echo e(route('courses.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['subjects.index','subjects.edit',]) ? 'active' : ''); ?>">
                        <i class="fa fa-book"></i> <span>Courses</span>
                    </a>
                </li>

                <!-- <li class="nav-item">-->
                <!--    <a href="<?php echo e(route('exams.index')); ?>"-->
                <!--       class="nav-link ">-->
                <!--        <i class="fa fa-clock-o" aria-hidden="true"></i>-->
                <!--        <span>Upload Exam</span></a>-->
                <!--</li>-->

                
                <li class="nav-item nav-item-submenu ">
                    <a href="#" class="nav-link"><i class="icon-pin"></i> <span>Subjects Management</span></a>
                    <ul class="nav nav-group-sub" data-submenu-title="Manage Subjects">
                        <li class="nav-item">
                            <a href="<?php echo e(route('subjects.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['subjects.index','subjects.edit',]) ? 'active' : ''); ?>"><i></i>
                                                     <span>Subjects</span>
                                                 </a>
                        </li>

                    </ul>
                </li>

                 <?php endif; ?> <?php if(Qs::userIsTeamSAT()): ?>
                <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                    <a href="#" class="nav-link"><i class="fa fa-sticky-note"></i> <span> Reporting</span></a>

                    <ul class="nav nav-group-sub" data-submenu-title="Manage Students">
                         
                        <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.list', 'students.edit', 'students.show']) ? 'nav-item-expanded' : ''); ?>">
                            <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.list', 'students.edit', 'students.show']) ? 'active' : ''); ?>">
                                <i class="icon-users" aria-hidden="true"></i>Class wise Students
                            </a>
                            <ul class="nav nav-group-sub">
                                <?php $__currentLoopData = App\Models\MyClass::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('students.list', $c->id)); ?>" class="nav-link ">
                                        <i class="fa fa-university" aria-hidden="true"></i> <?php echo e($c->name); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                         <?php if(Qs::userIsTeamSA()): ?>

                        <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'nav-item-expanded' : ''); ?>">
                            <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'active' : ''); ?>">
                                <i class="icon-users" aria-hidden="true"></i>Teacher
                            </a>
                            <ul class="nav nav-group-sub">

                                <a href="<?php echo e(route('teachers.list')); ?>" class="nav-link ">
                                    <i class="icon-users" aria-hidden="true"></i>Teacher's Record</a>

                            </ul>
                        </li>
                        <?php endif; ?>
                        <!--                            -->

                        <!--                            -->
                        <!--                            -->
                        <!--                            -->
                        <!--                            -->
                        <!--                            -->
                        <!--                            -->

                        <!--                            -->

                        <!--                            -->
                        <!--                            -->
                        <!--                            -->

                    </ul>
                </li>
                <?php endif; ?>          

                     
                
                     
                     
                       
                     
                        <?php if(Qs::userIsTeamSA()): ?>


                <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['exams.index', 'exams.edit', 'grades.index', 'grades.edit', 'marks.index', 'marks.manage', 'marks.bulk', 'marks.tabulation', 'marks.show', 'marks.batch_fix',]) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                    <a href="#" class="nav-link"><i class="icon-books"></i>
                            <span> Website Management (CMS)</span></a>

                    <ul class="nav nav-group-sub" data-submenu-title="">
                        <?php if(Qs::userIsTeamSA()): ?>



                        <li class="nav-item nav-item-submenu ">
                            <a href="#" class="nav-link"><i class="icon-office"></i> <span> Home Page</span></a>

                            <ul class="nav nav-group-sub" data-submenu-title="Administrative">

                                <li class="nav-item">
                                    <a href="<?php echo e(route('homepage.index')); ?>" class="nav-link <?php echo e((Route::is('frontcourse.index')) ? 'active' : ''); ?>">
                                        <i class="fa fa-book"></i> Home Page
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('homepagegallery.index')); ?>" class="nav-link <?php echo e((Route::is('frontcourse.index')) ? 'active' : ''); ?>">
                                        <i class="fa fa-book"></i> Home Page Gallery
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('homepagevideo.index')); ?>" class="nav-link <?php echo e((Route::is('frontcourse.index')) ? 'active' : ''); ?>">
                                        <i class="fa fa-book"></i> Home Page Video
                                    </a>
                                </li>
                            </ul>





                            <li class="nav-item">
                                <a href="<?php echo e(route('frontcourse.index')); ?>" class="nav-link <?php echo e((Route::is('frontcourse.index')) ? 'active' : ''); ?>">
                                    <i class="fa fa-book"></i> Course</a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('frontpricing.index')); ?>" class="nav-link <?php echo e((Route::is('frontpricing.index')) ? 'active' : ''); ?>">
                                    <i class="fa fa-usd" aria-hidden="true"></i>Pricing</a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('fronttestimonial.index')); ?>" class="nav-link <?php echo e((Route::is('fronttestimonial.index')) ? 'active' : ''); ?>">
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>Testimonial</a>
                            </li>


                            <li class="nav-item">
                                <a href="<?php echo e(route('frontblog.index')); ?>" class="nav-link <?php echo e((Route::is('frontblog.index')) ? 'active' : ''); ?>">
                                    <i class="fa fa-rss-square" aria-hidden="true"></i>Blog</a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('frontfaq.index')); ?>" class="nav-link <?php echo e((Route::is('frontfaq.index')) ? 'active' : ''); ?>">
                                    <i class="fa fa-question-circle" aria-hidden="true"></i>Faq</a>
                            </li>


                            <li class="nav-item">
                                <a href="<?php echo e(route('frontgallery.index')); ?>" class="nav-link <?php echo e((Route::is('frontgallery.index')) ? 'active' : ''); ?>">
                                    <i class="fa fa-picture-o" aria-hidden="true"></i>Gallery</a>
                            </li>



                            <?php endif; ?>


                    </ul>
                    </li>

                     <?php endif; ?>  <?php if(Qs::userIsTeamSA()): ?>
                    <li class="nav-item nav-item-submenu">
                        <a href="#" class="nav-link"><i class="fa fa-list-alt"></i> <span> Applications </span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="Manage Students">

                            <li class="nav-item">
                                <a href="<?php echo e(route('students.general_app')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.general_app']) ?  : ''); ?>">
                                    <i class="fa fa-list-alt" aria-hidden="true"></i>
                                    <span>General Application</span></a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('students.drop_a_complain')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.drop_a_complain']) ?  : ''); ?>">
                                    <i class="fa fa-dropbox" aria-hidden="true"></i> <span>Drop a Complain</span></a>
                            </li>
                        </ul>
                    </li>

                    <li class="nav-item nav-item-submenu ">
                        <a href="#" class="nav-link"><i class="fa fa-check-circle" aria-hidden="true"></i> <span>Evaluation</span></a>
                        <ul class="nav nav-group-sub" data-submenu-title="Manage Subjects">
                            <li class="nav-item">
                                <a href="<?php echo e(route('student_evaluation.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['subjects.index','subjects.edit',]) ? 'active' : ''); ?>">
                                    <i class="icon-user" aria-hidden="true"></i> <span>Students Evaluation</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('teacher_evaluation.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['subjects.index','subjects.edit',]) ? 'active' : ''); ?>">
                                    <i class="icon-user" aria-hidden="true"></i> <span>Teachers Evaluation</span>
                                </a>
                            </li>
                        </ul>
                    </li>


                    <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>
                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                        <a href="#" class="nav-link"><i class="fa fa-bullhorn" aria-hidden="true"></i> <span> Announcements </span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="Manage Students">

                            <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'nav-item-expanded' : ''); ?>">
                                <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'active' : ''); ?>">
                                    <i class="fa fa-list-alt" aria-hidden="true"></i>Instructions
                                </a>
                                <ul class="nav nav-group-sub">

                                    <a href="<?php echo e(route('std_ins.index')); ?>" class="nav-link "><i class="icon-user" aria-hidden="true"></i>Students
                                        Instructions</a>

                                </ul>
                                <ul class="nav nav-group-sub">

                                    <a href="<?php echo e(route('teacher_ins.index')); ?>" class="nav-link "><i class="icon-user" aria-hidden="true"></i>Teachers
                                        Instructions</a>
                                </ul>
                            </li>

                             <?php if(Qs::userIsTeamSA()): ?>

                            <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'nav-item-expanded' : ''); ?>">
                                <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'active' : ''); ?>">
                                    <i class="fa fa-bell" aria-hidden="true"></i>Notification
                                </a>
                                <ul class="nav nav-group-sub">

                                    <a href="<?php echo e(route('std_noti.index')); ?>" class="nav-link "><i class="icon-user" aria-hidden="true"></i>Students
                                            Notification</a>

                                </ul>
                                <ul class="nav nav-group-sub">

                                    <a href="<?php echo e(route('teacher_noti.index')); ?>" class="nav-link "><i class="icon-user" aria-hidden="true"></i>Teachers
                                            Notification</a>

                                </ul>
                            </li>

                            <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'nav-item-expanded' : ''); ?>">
                                <a href="#" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['teachers.list', 'teachers.edit', 'teachers.show']) ? 'active' : ''); ?>">
                                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i>Updates
                                </a>
                                <ul class="nav nav-group-sub">

                                    <a href="<?php echo e(route('std_updates.index')); ?>" class="nav-link "><i class="icon-user" aria-hidden="true"></i>Students Class
                                            Updates</a>

                                </ul>
                                <ul class="nav nav-group-sub">

                                    <a href="<?php echo e(route('teacher_updates.index')); ?>" class="nav-link "><i class="icon-user" aria-hidden="true"></i>Teachers
                                            Updates</a>

                                </ul>
                            </li>


                            <?php endif; ?>
                            <!--                            -->

                            <!--                            -->
                            <!--                            -->
                            <!--                            -->
                            <!--                            -->
                            <!--                            -->
                            <!--                            -->

                            <!--                            -->

                            <!--                            -->
                            <!--                            -->
                            <!--                            -->

                        </ul>
                    </li>
                    <?php endif; ?> <?php if(Qs::userIsTeacher()): ?>

                    <li class="nav-item">
                        <a href="<?php echo e(route('teacher.my_courses')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>My Courses</span></a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('teacher.my_students')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>My Students</span></a>
                    </li>



                    <li class="nav-item">
                        <a href="<?php echo e(route('teacher.uploadlecture')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>Upload Study Material</span></a>
                    </li>


                    <li class="nav-item ">
                        <a href="<?php echo e(route('teacher_assignment.index')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>Upload Assignment</span></a>
                    </li>

                    <!--<li class="nav-item">-->
                    <!--    <a href="<?php echo e(route('exams.index')); ?>"-->
                    <!--       class="nav-link "-->
                    <!--    >-->
                    <!--        <i class="fa fa-clock-o" aria-hidden="true"></i>-->
                    <!--        <span>Upload Exam</span></a>-->
                    <!--</li>-->


                    <li class="nav-item">
                        <a href="<?php echo e(route('teacher.paper')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>Create Paper</span></a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('teacher.resultlist')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>Result List</span></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('teacher.scheduleAClass')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>Schedule A Class</span></a>
                    </li>

                    <li class="nav-item ">
                        <a href="<?php echo e(route('teachers.view.survey')); ?>" class="nav-link ">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            <span>View Student Feedback</span></a>
                    </li>


                    <li class="nav-item">
                        <a href="<?php echo e(route('teachers.teacer_rules')); ?>" class="nav-link ">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>
                            <span>Rules And Regulations</span></a>
                    </li>




                    <?php endif; ?> <?php if(Qs::userIsStudent()): ?>

                    <li class="nav-item">
                        <a href="<?php echo e(route('students.class_schedule')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.class_schedule']) ?  : ''); ?>">
                            <i class="fa fa-clock-o" aria-hidden="true"></i> <span>Online Class Schedule</span></a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('students.course_register')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.course_register']) ?  : ''); ?>">
                            <i class="fa fa-list-alt" aria-hidden="true"></i> <span>Registered Courses</span></a>
                    </li>




                    <li class="nav-item">
                        <a href="<?php echo e(route('students.offered_courses')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.offered_courses']) ?  : ''); ?>">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>

                            <span>Offered Courses</span></a>
                    </li>




                    <li class="nav-item">
                        <a href="<?php echo e(route('students.survey')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['students.survey']) ?  : ''); ?>">
                            <i class="fa fa-file-text" aria-hidden="true"></i> <span>Survey for students</span></a>
                    </li>

                    <li class="nav-item nav-item-submenu <?php echo e(in_array(Route::currentRouteName(), ['students.create', 'students.list', 'students.edit', 'students.show', 'students.promotion', 'students.promotion_manage', 'students.graduated']) ? 'nav-item-expanded nav-item-open' : ''); ?> ">
                        <a href="#" class="nav-link"><i class="fa fa-table"
                                                        aria-hidden="true"></i><span> Study Material </span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="Manage Students">

                                      

                            <li class="nav-item">
                                <a href="<?php echo e(route('student.lecture.show')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['student.lecture.show']) ?  : ''); ?>"><i
                                        class="icon-user"></i> <span>Lectures</span></a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('student_assignment.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['student_assignment.index']) ?  : ''); ?>"><i
                                        class="icon-user"></i> <span>Assignment</span></a>
                            </li>

                                     

                        </ul>
                    </li>


                          


                    <li class="nav-item">
                        <a href="<?php echo e(route('std_paper.paper.index')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['std_paper.paper.index']) ?  : ''); ?> "><i
                                class="fa fa-comments" aria-hidden="true"></i> <span>Start Online Exam</span></a>
                    </li>



                    <li class="nav-item nav-item-submenu">
                        <a href="#" class="nav-link"><i class="fa fa-list-alt" aria-hidden="true"></i> <span> Application </span></a>

                        <ul class="nav nav-group-sub" data-submenu-title="Manage Students">

                            <li class="nav-item">
                                <a href="<?php echo e(route('individual_students.general_app')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['individual_students.general_app']) ?  : ''); ?>"><i
                                        class="fa fa-list-alt" aria-hidden="true"></i> <span>General Application</span></a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('individual_students.drop_a_complain')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['individual_students.drop_a_complain']) ?  : ''); ?>">
                                    <i class="fa fa-dropbox" aria-hidden="true"></i><span>Drop a Complain</span></a>
                            </li>
                        </ul>
                    </li>

                      
                        


                    <li class="nav-item">
                        <a href="<?php echo e(route('students.student_rules')); ?>" class="nav-link ">
                            <i class="fa fa-list-alt" aria-hidden="true"></i>
                            <span>Rules And Regulations</span></a>
                    </li>

                    <?php endif; ?> <?php if(Qs::userIsTeamSA()): ?>


                    <li class="nav-item">
                        <a href="<?php echo e(route('policies.index')); ?>" class="nav-link ">

                            <i class="fa fa-list"></i>
                            <span>Policy</span></a>
                    </li>
                    <?php endif; ?>    

                    <li class="nav-item">
                        <a href="<?php echo e(route('my_account')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['my_account']) ? 'active' : ''); ?>"><i
                            class="icon-user"></i> <span>My Account</span></a>
                    </li>

                     

                 

            </ul>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/partials/menu.blade.php ENDPATH**/ ?>