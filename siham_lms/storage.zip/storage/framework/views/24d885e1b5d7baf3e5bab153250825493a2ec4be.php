<?php $__env->startSection('page_title', 'View Students Feedback'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">

        
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Students Opted Your Course</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#manage-course" class="nav-link" data-toggle="tab">Manage Students click
                        here</a>
                </li>

            </ul>
            <div class="tab-content">
                <h1>List of students </h1>
                <div class="tab-pane show active" id="manage-course">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Course Name</th>
                            <th>Student Name</th>
                            <th>Feedback</th>
                        </tr>
                        </thead>
                        <tbody>
                        

                        <?php $__currentLoopData = $courseReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courReg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <?php if(isset($courReg->courses->id)): ?>
                                    <td><?php echo e($courReg->courses->name); ?></td>
                                <?php else: ?>
                                    <td>no name</td>
                                <?php endif; ?>

                                <?php if($courReg->users->name): ?>
                                    <td><?php echo e($courReg->users->name); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($courReg->user_id); ?></td>
                                <?php endif; ?>
                                <td>
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#exampleModal<?php echo e($courReg->id); ?>">
                                        view Feedback
                                    </button>
                                    <a href="<?php echo e('students/show_online_paper_result?id='.$courReg->user_id); ?>" class="btn btn-primary">Result</a>
                                </td>

                                <div class="modal fade" id="exampleModal<?php echo e($courReg->id); ?>" tabindex="-1" role="dialog"
                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        
                                        <?php
                                            $std_surveys  = \App\Models\StudentSurvey::where('std_id',$courReg->user_id)->get();
                                        ?>
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                <?php $__currentLoopData = $std_surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std_survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <ul>






                                                            <?php
                                                             $std_surveys_ques  = \App\Models\StudentEvaluation::where('id',$std_survey->question_id)->get();
                                                            ?>


                                                            <li>
                                                                <?php $__currentLoopData = $std_surveys_ques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std_surveys_que): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                Question No:<?php echo e($std_survey->question_id); ?> :- <?php echo e($std_surveys_que->question); ?>


                                                                <br>
                                                                Answer:-  <?php echo e($std_survey->answer); ?>

                                                                 <br><br>
                                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </li>








                                                    </ul>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                    Close
                                                </button>
                                                <button type="button" class="btn btn-primary">Save changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>



    <!-- Modal -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/students/teacherStdFeedback.blade.php ENDPATH**/ ?>