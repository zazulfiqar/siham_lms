<?php $__env->startSection('page_title', 'Offered Courses'); ?>
<?php $__env->startSection('content'); ?>
<style>
.registerNowBtnDiv {
    /* margin: 20px; */
    text-align: center;
    background-color: #f41043;
    margin: 12px;
    color: white;
    text-decoration: none;
    border-radius: 10px;
    /* height: 30px; */
    padding: 12px;
}
a.registerNowBtn {
    color: white;
}
</style>
<div class="card">
    <div class="card-header header-elements-inline">
        
        <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body">
        <section class="page-contain">
            <div class="row">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <a href="#" class="data-card">
                        <h3><?php if($course->code == null || $course->code == ''): ?>
                            Not Assign
                        <?php else: ?>
                            <?php echo e($course->code); ?>

                        <?php endif; ?></h3>
                        <h4>
                            <?php if($course->name): ?>
                                 <?php echo e($course->name); ?><?php echo e($course->id); ?>

                            <?php else: ?>
                                 Course
                            <?php endif; ?>
                        </h4>
                        <p>

                        </p>
                        <span class="link-text">
                            <?php if(isset($course->teachers->name)): ?>
                            <td> <?php echo e($course->teachers->name); ?></td>
                                    <?php else: ?>
                                    <td>Teacher Not Assign Yet</td>
                                <?php endif; ?>
                        <svg width="25" height="16" viewBox="0 0 25 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M17.8631 0.929124L24.2271 7.29308C24.6176 7.68361 24.6176 8.31677 24.2271 8.7073L17.8631 15.0713C17.4726 15.4618 16.8394 15.4618 16.4489 15.0713C16.0584 14.6807 16.0584 14.0476 16.4489 13.657L21.1058 9.00019H0.47998V7.00019H21.1058L16.4489 2.34334C16.0584 1.95281 16.0584 1.31965 16.4489 0.929124C16.8394 0.538599 17.4726 0.538599 17.8631 0.929124Z" fill="#753BBD"/>
                    </svg>
                        </span>
                    </a>
                    <div class="registerNowBtnDiv">
                        <a class="registerNowBtn" href="<?php echo e(route('students.course_register.store',\App\Helpers\Qs::hash($course->id))); ?>">
                            Register Now
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </section>
    </div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/offeredCourses/index.blade.php ENDPATH**/ ?>