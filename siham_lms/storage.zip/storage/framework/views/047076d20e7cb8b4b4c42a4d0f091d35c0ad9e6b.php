
<?php $__env->startSection('page_title', 'My Students'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">

        
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Students Opted Your Course</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#manage-course" class="nav-link" data-toggle="tab">Manage Students click
                        here</a>
                </li>

            </ul>
            <div class="tab-content">
                <div class="tab-pane show active"  id="manage-course">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Time Slot</th>
                            <th>Course Name</th>
                            <th>Student Name</th>
                            <th>Student Email</th>
                            <th>Code</th>
                            <th>Description</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($course->time_slot); ?></td>
                                <td><?php echo e($course->name); ?></td>
                                <td><?php echo e($course->student_name); ?></td>
                                <td><?php echo e($course->student_email); ?></td>







                                <td><?php echo e($course->code); ?></td>
                                <td><?php echo e($course->description); ?></td>
























                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/teacher_students/index.blade.php ENDPATH**/ ?>