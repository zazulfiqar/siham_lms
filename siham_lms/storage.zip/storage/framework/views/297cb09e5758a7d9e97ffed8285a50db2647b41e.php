
<?php $__env->startSection('page_title', 'Uploaded Assignment Here by Teacher'); ?>
<?php $__env->startSection('content'); ?>




    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Uploaded Assignment</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#manage-course" class="nav-link" data-toggle="tab">All Assignment
                        Material</a>
                </li>
            </ul>

            <div class="tab-content">
                <div class="tab-pane active" id="manage-course">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Course Name</th>
                            <th>Class Name</th>
                            <th>Topic</th>
                            <th>Description</th>
                            <th>file</th>
                            <th>Upload File</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <?php if(isset($assignment->courses->name)): ?>
                                    <td><?php echo e($assignment->courses->name); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($assignment->course_id); ?></td>

                                <?php endif; ?>
                                <?php if(isset($assignment->class->name)): ?>
                                    <td><?php echo e($assignment->class->name); ?></td>
                                <?php else: ?>
                                    <td></td>
                                <?php endif; ?>

                                <?php if(isset($assignment->topic)): ?>
                                    <td><?php echo e($assignment->topic); ?></td>
                                <?php else: ?>
                                    <td>no-topic</td>
                                <?php endif; ?>

                                <?php if(isset($assignment->description)): ?>

                                    <td><?php echo e($assignment->description); ?></td>
                                <?php else: ?>
                                    <td>no-desc</td>
                                <?php endif; ?>
                                <?php if(isset($assignment->file)): ?>
                                    <td><a href="<?php echo e(url('/siham_lms/storage/app/public/'.$assignment->file	)); ?>" target="_blank">Download
                                            file</a></td>
                                <?php else: ?>
                                    <td>No file</td>
                                <?php endif; ?>

                                <?php
                                    $stdAssignmentStatus =\App\Models\StudentAssignment::where('assignment_id',$assignment->id)->get();
                             
                                ?>
                                <?php if(count($stdAssignmentStatus)>0): ?>
                                    <td > <a href="javascript:void(0)"> Submitted </a></td>
                                <?php else: ?>
                                    <td>
                                        <form class="" method="post" id="form"
                                              action="<?php echo e(route('student_assignment.store')); ?>"
                                              enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('post'); ?>
                                            <input type="file" name="file" id="file">

                                            <input type="hidden" name="assignment_id" value="<?php echo e($assignment->id); ?>">
                                            <input type="submit">
                                        </form>
                                    </td>
                                <?php endif; ?>

                               
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>document.getElementById("file").onchange = function () {
            document.getElementById("form").submit();
        };</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/studentAssignment/index.blade.php ENDPATH**/ ?>