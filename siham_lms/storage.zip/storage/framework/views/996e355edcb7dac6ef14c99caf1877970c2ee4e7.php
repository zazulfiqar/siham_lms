<?php $__env->startSection('page_title', 'Student Policies'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Student Policies</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>

        <div class="card-body">


            <div class="row">


                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="card flex-row flex-wrap">
                        <div class="card-footer w-100 text-muted">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>   Privacy Policy
                        </div>
                        <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policysingle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-body">
                                <p><?php echo e($policysingle->policy); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="tab-pane fade" id="new-class">
                    <div class="row">
                        <div class="col-md-12">
                            
                            

                            
                            
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            

                            <form class="" method="post" action="<?php echo e(route('policies.store')); ?>">

                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="class_type_id" class="col-lg-3 col-form-label font-weight-semibold">Role
                                        Type</label>
                                    <div class="col-lg-9">
                                        <select required data-placeholder="Select Class Type"
                                                class="form-control select" name="role_type" id="role_type">
                                            <option value="student">Student</option>
                                            <option value="teacher">Teacher</option>
                                            <option value="staff">Staff</option>

                                        </select>
                                    </div>
                                </div>


                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label font-weight-semibold">Policy Description<span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        
                                        
                                        <textarea id="" name="policy" rows="10" cols="120"></textarea>


                                    </div>
                                </div>


                                <div class="text-right">
                                    <button id="ajax-btn" type="submit" class="btn btn-primary">Submit form <i
                                            class="icon-paperplane ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/policies/student_policy.blade.php ENDPATH**/ ?>