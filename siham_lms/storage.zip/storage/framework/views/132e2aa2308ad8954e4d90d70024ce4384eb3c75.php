<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body class="innerpages body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Header End -->

<!-- innerBanner start -->
		<div class="innerBanner">
            <?php if($faq_header_image == null): ?>
                <img src="<?php echo e(asset('images/Bannar-4.jpg')); ?>" class="img-responsive" alt="courses-Banner">
            <?php endif; ?>
            <?php if($faq_header_image != null): ?>
                <img src="<?php echo e(url('/siham_lms/storage/app/public/'.$faq_header_image	)); ?>"  class="img-responsive" alt="courses-Banner">

            <?php endif; ?>


			<div class="innerBannerOverlay">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<h1>FAQ's</h1>
					</div>
				</div>
			</div>
		</div>
<!-- innerBanner end -->

   <div class="clear"></div>

    <!-- faq-section -->
    <div class="faq_section padding_both">
      <div class="container">
        <div class="row">
          <div class="col-md-9 col-sm-9 col-xs-12 center">
            <div class="startLearning_head">
              <h2 data-aos="fade-down">Frequently Asked Questions</h2>
              <p data-aos="fade-down">Here are some answers to common questions we get from students about Knowledge Society Learning. If your question is not answered below, contact us to assist.</p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-9 col-sm-9 col-xs-12 center">
            <div class="faq_text">
              <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                  <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="panel panel-default" data-aos="zoom-in" data-aos-delay="300">
                  <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title">
                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($index+1); ?>" aria-expanded="true" aria-controls="collapseOne">
                       <?php echo e($faq->faq); ?>?
                    </a>
                  </h4>
                  </div>
                  <div id="<?php echo e($index+1); ?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body">
                      <?php echo e($faq->description); ?>

                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!--<div class="panel panel-default" data-aos="zoom-in" data-aos-delay="400">-->
                <!--  <div class="panel-heading" role="tab" id="headingTwo">-->
                <!--    <h4 class="panel-title">-->
                <!--    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">-->
                <!--      Is lorem ipsum a replacement for college?-->
                <!--    </a>-->
                <!--  </h4>-->
                <!--  </div>-->
                <!--  <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">-->
                <!--    <div class="panel-body">-->
                <!--      Knowledge Society focuses on four main pillars of online education: health, wealth, love, and happiness. At this time, we're focusing on wealth - practical skills that you can use to start or grow your career. Because there's multiple courses, you will learn both beginner and advanced concepts.-->
                <!--    </div>-->
                <!--  </div>-->
                <!--</div>-->

                <!--<div class="panel panel-default" data-aos="zoom-in" data-aos-delay="500">-->
                <!--  <div class="panel-heading" role="tab" id="headingThree">-->
                <!--    <h4 class="panel-title">-->
                <!--    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">-->
                <!--      Who's teaching lorem ipsum courses?-->
                <!--    </a>-->
                <!--  </h4>-->
                <!--  </div>-->
                <!--  <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">-->
                <!--    <div class="panel-body">-->
                <!--      Knowledge Society focuses on four main pillars of online education: health, wealth, love, and happiness. At this time, we're focusing on wealth - practical skills that you can use to start or grow your career. Because there's multiple courses, you will learn both beginner and advanced concepts.-->
                <!--    </div>-->
                <!--  </div>-->
                <!--</div>-->


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- faq-section -->



    <!--Footer Content Start-->
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/frontend/faq.blade.php ENDPATH**/ ?>