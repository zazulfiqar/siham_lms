
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Active Students List</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="all-students">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $activeStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img class="rounded-circle" style="height: 40px; width: 40px;"
                                         src="<?php echo e(url('/siham_lms/storage/app/public/'.$students->photo	)); ?>" alt="photo"></td>
                                <td><?php echo e($students->name); ?></td>
                                <td><?php echo e($students->username); ?></td>
                                <td><?php echo e($students->email); ?></td>
                                <td class="text-center">
                                    <div class="list-icons">
                                        <div class="dropdown">
                                            <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                <i class="icon-menu9"></i>
                                            </a>
                                            
                                            <div class="dropdown-menu dropdown-menu-left">
                                                <?php if(isset($students->student_record->id)): ?>
                                                <a href="<?php echo e(route('students.show',
                                                Qs::hash($students->student_record->id))); ?>"
                                                   class="dropdown-item"><i class="icon-eye"></i> View Profile</a>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('students.inactive', Qs::hash($students->id))); ?>"
                                                   class="dropdown-item"><i class="icon-blocked"></i>Deactivate</a>
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/students/activeStudents.blade.php ENDPATH**/ ?>