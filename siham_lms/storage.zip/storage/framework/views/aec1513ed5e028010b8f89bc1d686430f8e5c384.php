<?php $__env->startSection('page_title', 'Registerated Courses '); ?>
<?php $__env->startSection('content'); ?>







    <div class="card">
        <div class="container">
            <div class="card-header header-elements-inline">
                
                <?php echo Qs::getPanelOptions(); ?>

            </div>

            <?php $topics=DB::table('courses_study_plan')->where('course_id',$details->course_id)->get();
            ?>

            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="card flex-row flex-wrap">
                    <div class="card-footer w-100 text-muted">
                        Course Topics
                    </div>
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dbs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <br>
                            <div class="card-block px-2">
                                <h5 class="card-title"><?php echo e($dbs->name); ?></h5>
                                <p class="card-text"><?php echo e($dbs->study_plan); ?></p>
                            </div>
                        <div class="w-100"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php $assignments=DB::table('teacher_assignments')->where('course_id',$details->course_id)->get();
            ?>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="card flex-row flex-wrap">
                    <div class="card-footer w-100 text-muted">
                        Assignments
                    </div>
                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <br>
                            <div class="card-block px-2">
                                <h5 class="card-title"><?php echo e($assign->topic); ?></h5>
                                <p class="card-text"><?php echo e($assign->description); ?></p>

                                <p class="card-text"><a href="<?php echo e(asset('siham_lms/storage/app/public/'.$assign->file )); ?>" target="_blank">Download
                                    file</a></p>
                            </div>
                        <div class="w-100"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php $lactures=DB::table('lectures')->where('course_id',$details->course_id)->get();
            ?>

            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="card flex-row flex-wrap">
                    <div class="card-footer w-100 text-muted">
                        Lactures
                    </div>
                    <?php $__currentLoopData = $lactures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <br>
                            <div class="card-block px-2">
                                <h5 class="card-title"><?php echo e($lac->topic); ?></h5>
                                <p class="card-text"><?php echo e($lac->description); ?></p>
                                <p class="card-text">
                                    <a href="<?php echo e(asset('siham_lms/storage/app/public/'.$lac->file )); ?>" target="_blank">Download
                                        file</a>
                                    </p>
                                
                            </div>
                        <div class="w-100"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/courseRegistrations/courseDetails.blade.php ENDPATH**/ ?>