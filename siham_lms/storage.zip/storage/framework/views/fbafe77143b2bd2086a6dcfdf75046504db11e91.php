  <?php $__env->startSection('content'); ?>

<div class="card">

    <div class="card-header header-elements-inline">

        <a href="<?php echo e(route('homepagevideo.create')); ?>" class="btn btn-success">Add </a> <?php echo Qs::getPanelOptions(); ?>

    </div>

    <div class="card-body">
        <ul class="nav nav-tabs nav-tabs-highlight">
                    
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="all-students">
                <table class="table datatable-button-html5-columns">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Title</th>
                            <th>Content</th>

                            <th>Youtube</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $getRecordFrontHomeGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getRecordFront): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>


                            <td><?php echo e($getRecordFront->name); ?></td>
                            <td><?php echo e($getRecordFront->content); ?></td>
                            <td><?php echo e($getRecordFront->youtubeurl); ?></td>
                            <td><img src="<?php echo e(URL::asset('uploadsVideoImage/'.$getRecordFront->photo)); ?>" width="50" height="50"></td>
                            <td> <a href="<?php echo e(route('homepagevideo.edit',  $getRecordFront->id)); ?>" class="dropdown-item"> Edit</a>




                                <form class="" method="post" action="<?php echo e(route('homepagevideo.destroy', $getRecordFront->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>

                                    <input type="submit" class="dropdown-item" value="Delete">
                                    </i>
                                </form>

                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>


                                   
                
                                      

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/WebManagement/homepage/homepagevideos/store.blade.php ENDPATH**/ ?>