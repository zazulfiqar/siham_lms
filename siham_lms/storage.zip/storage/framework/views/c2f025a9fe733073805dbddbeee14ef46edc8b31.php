<?php $__env->startSection('page_title', 'Manage Paper'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Result </h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">

            <div class="tab-content">


                <div class="" id="">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>

                            <th>Question</th>
                            <th>Answer</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>


                            <?php $__currentLoopData = $getQuestion_answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getQuestions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <td>

                                    <?php
                                        $papersData  = \App\Models\OnlinePaper::where('id',$getQuestions->question_id)->first();
                                        echo $papersData->question;
                                      ?>

                                </td>
                                <td><?php echo e($getQuestions->answer); ?></td>

                                <td class="text-center">
                                    
                                        
                                        

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/papers/result_by_student.blade.php ENDPATH**/ ?>