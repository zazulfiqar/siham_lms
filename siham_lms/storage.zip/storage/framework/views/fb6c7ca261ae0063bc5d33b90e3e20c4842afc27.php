<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="innerpages body_bg">
<!-- Header Start -->
<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header End -->
<!-- innerBanner start -->
<div class="innerBanner">
    <?php if($blog_header_image == null): ?>
        <img src="<?php echo e(asset('images/Bannar-2.jpg')); ?>" class="img-responsive" alt="courses-Banner">
    <?php endif; ?>
    <?php if($blog_header_image != null): ?>
        <img src="<?php echo e(url('/siham_lms/storage/app/public/'.$blog_header_image	)); ?>"  class="img-responsive" alt="courses-Banner">
    <?php endif; ?>
    <div class="innerBannerOverlay">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <h1>Blogs</h1>
            </div>
        </div>
    </div>
</div>
<!-- innerBanner end -->
<!-- Blog-section -->
<div class="Blog_section">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-sm-10 col-xs-12 center">
                <div class="startLearning_head">
                    <h2 data-aos="fade-down">Our Blogs</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="blog_Box wow bounceIn" data-wow-delay="0.2s" data-wow-duration="2s">
                        <p> <?php echo e(\Illuminate\Support\Str::limit($blog->description, 300, $end='...')); ?> </p>
                    <!--<p><?php echo e($blog->description); ?></p>-->




                        <a href="<?php echo e(route('blogdetail', Qs::hash($blog->id))); ?>"
                           class="dropdown-item"><i class="icon-checkbox-checked2"></i> Read more</a>


                        <div class="blog_BoxOverlay">
                            <p>
                                <?php echo e(\Illuminate\Support\Str::limit($blog->title, 70, $end='...')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Blog-section -->
<!--Footer Content Start-->
<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Footer Content End-->
<!-- Js Files Start -->
<script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
<script src="<?php echo e(asset('js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/frontend/blog.blade.php ENDPATH**/ ?>