<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="innerpages body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Header End -->

<!-- innerBanner start -->
<div class="innerBanner">
    <img src="<?php echo e(asset('images/Bannar-2.jpg')); ?>" class="img-responsive" alt="courses-Banner">
    <div class="innerBannerOverlay">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <h1>Blog Detail</h1>
            </div>
        </div>
    </div>
</div>
<!-- innerBanner end -->

<!-- Blog-section -->
<div class="BlogDetail_page">
<div class="container">
<div class="row">
  <div class="col-md-10 col-sm-10 col-xs-12 center">
   <div class="BlogDetail_text">
      <img src="<?php echo e(asset('images/BlogDetail_img1.jpg')); ?>" alt="img">
      <h2><?php echo e($frontblog->title); ?></h2>
      

   <p><?php echo e($frontblog->description); ?></p>
   </div>
   
   
  </div>
</div>
</div>
</div>
<!-- Blog-section -->



<!--Footer Content Start-->

<!--Footer Content End-->

    <!-- Saying-section -->



    <!--Footer Content Start-->
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  </body>
</html>
<?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/frontend/blogdetails.blade.php ENDPATH**/ ?>