<?php $__env->startSection('page_title', 'Edit Course Content'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card">





        <div class="card-body">
            <div class="row">
                <div class="col-md-12">

                    <form class="" method="post" action="<?php echo e(route('frontpricing.update', $pricings->id)); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>


                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">Title
                                <span class="text-danger">*</span></label>
                            <div class="col-md-9">
                                <input type="text"  class="form-control" name="title" value="<?php echo e($pricings->title); ?>">
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">Course
                                Duration
                                <span class="text-danger">*</span></label>
                            <div class="col-md-9">
                                <input type="text"  class="form-control" name="course_duration" value="<?php echo e($pricings->course_duration); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">price
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text"  class="form-control" name="price" value="<?php echo e($pricings->price); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">description
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text"  class="form-control" name="description" value="<?php echo e($pricings->description); ?>">

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">feature_One
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text"  class="form-control" name="feature_one" value="<?php echo e($pricings->feature_one); ?>">

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">feature_Two
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text" name="feature_two"  class="form-control" value="<?php echo e($pricings->feature_two); ?>">

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">feature_Three
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text" name="feature_three"  class="form-control" value="<?php echo e($pricings->feature_three); ?>">

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">feature_Four
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text" name="feature_four"  class="form-control" value="<?php echo e($pricings->feature_four); ?>">

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">feature_Five
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input type="text" name="feature_five"  class="form-control" value="<?php echo e($pricings->feature_five); ?>">

                            </div>
                        </div>




                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Submit form <i class="icon-paperplane ml-2"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/WebManagement/pricings/edit.blade.php ENDPATH**/ ?>