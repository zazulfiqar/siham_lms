<header>
    <div class="main_header">

        <?php $tabname=Request::path(); ?>

        <div class="container">
            <div class="row flexRow">
                <div class="col-md-7 hidden-sm hidden-xs">
                    <div class="menuSec">
                        <ul id="menu">
                            <li><a href="<?php echo e(asset('/')); ?>" <?php if($tabname=='/' ): ?> class="active" <?php endif; ?>>Home</a></li>
                            <li><a href="<?php echo e(asset('course')); ?>" <?php if($tabname=='course' ): ?> class="active" <?php endif; ?>>Course</a></li>
                            <li><a href="<?php echo e(asset('pricing')); ?>" <?php if($tabname=='pricing' ): ?> class="active" <?php endif; ?>>Pricing </a></li>
                            <li><a href="<?php echo e(asset('testimonials')); ?>" <?php if($tabname=='testimonials' ): ?> class="active" <?php endif; ?>>Testimonials </a></li>
                            <li><a href="<?php echo e(asset('blog')); ?>" <?php if($tabname=='blog' ): ?> class="active" <?php endif; ?>>Blogs</a></li>
                            <li><a href="<?php echo e(asset('faq')); ?>" <?php if($tabname=='faq' ): ?> class="active" <?php endif; ?>>FAQ</a></li>
                            <li><a href="<?php echo e(asset('contact')); ?>" <?php if($tabname=='contact' ): ?> class="active" <?php endif; ?>>Contact Us</a></li>
                            
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12 flexCol">
                    <div class="nav_search">
                        <input type="text" placeholder="search here">
                        <button type="button"><img src="<?php echo e(asset('images/search_icon.png')); ?>"></button>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="nav_login">

                        <?php if(isset(Auth::user()->name)): ?>

                        <a href="<?php echo e(asset('dashboard')); ?>" class="btn_pink"> <span> <?php echo e(Auth::user()->name); ?> <i class="fa fa-user" aria-hidden="true"></i></span></a> <?php else: ?> <a href="Javascript:void(0)" class="btn_pink" data-toggle="modal" data-target="#modal1">login</a><?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/frontend/layout/header.blade.php ENDPATH**/ ?>