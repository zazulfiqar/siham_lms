<?php

$id = $_GET['id'];

?>

<?php
  // $get_std_online_papers=DB::table('std_online_papers')->select('std_id')->distinct()->where('paper_id', $request->paperid)->get();
  $get_std_online_papers  = \App\Models\StdOnlinePaper::select('std_id')->distinct()->where('paper_id', $id )->get();
?>









<?php $__env->startSection('page_title', 'Manage Paper'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Result </h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">

            <div class="tab-content">


                <div class="" id="">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>

                            <th>Paper Name</th>
                            <th>Student Name</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>


                            <?php $__currentLoopData = $get_std_online_papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get_std_online_paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                                    // $get_std_online_papers=DB::table('std_online_papers')->select('std_id')->distinct()->where('paper_id', $request->paperid)->get();
                                    $get_std_online_papers  = \App\Models\StdOnlinePaper::select('std_id')->distinct()->where('paper_id', $id )->get();
                                    ?>

                                    <?php
                                    $users  = \App\Models\User::where('id',$get_std_online_paper->std_id)->get();
                                    ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                    <td>
                                        <?php
                                        $papersData  = \App\Models\Paper::where('id',$id)->first();
                                        echo $papersData->topic;
                                      ?>
                                       </td>
                                <td><?php echo e($paper->name); ?></td>
                                <td>
                                    
                                        <form method="post" action="<?php echo e(route('teacher.resultbypaperAnswer')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('GET'); ?>
                                            <input type="hidden" class="btn btn-primary" name="std_id" value="<?php echo e($paper->id); ?>">
                                            <input type="hidden" class="btn btn-primary" name="paper_id" value="<?php echo e($papersData->id); ?>">

                                        <input type="submit" class="btn btn-primary" value="Result">
                                        </form>
                                </td>

                                <td></td>


                                <td class="text-center">
                                    
                                        
                                        

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/papers/show_all_result_list.blade.php ENDPATH**/ ?>