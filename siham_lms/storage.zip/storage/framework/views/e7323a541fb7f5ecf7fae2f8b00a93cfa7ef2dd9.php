
<?php $__env->startSection('page_title', 'View Students Feedback'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">

        
  
        <div class="card-body">
      
            <div class="tab-content">
                <h1> students Result </h1>
                <div class="tab-pane show active" id="manage-course">
                   

                            <?php $__currentLoopData = $std_online_papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




    <input type="radio" name="stdans" value="1" <?php echo ($result->std_online_papers_answer == '1'?'checked':''); ?> ><?php echo e($result->choice1); ?><br>
    <input type="radio" name="stdans" value="2" <?php echo ($result->std_online_papers_answer == '2'?'checked':''); ?>><?php echo e($result->choice2); ?><br>
    <input type="radio" name="stdans" value="3" <?php echo ($result->std_online_papers_answer == '3'?'checked':''); ?>><?php echo e($result->choice3); ?><br>
    <input type="radio" name="stdans" value="4" <?php echo ($result->std_online_papers_answer == '4'?'checked':''); ?>><?php echo e($result->choice4); ?><br>

                            
                         

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
               
                </div>
                
            </div>

            <div class="tab-content">
                <h1> Answer :</h1>
                <div class="tab-pane show active" id="manage-course">
                    <?php $__currentLoopData = $std_online_papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="radio" name="radio" value="1" <?php echo ($result->online_papers_answer == '1'?'checked':''); ?> ><?php echo e($result->choice1); ?><br>
                    <input type="radio" name="radio" value="2" <?php echo ($result->online_papers_answer == '2'?'checked':''); ?>><?php echo e($result->choice2); ?><br>
                    <input type="radio" name="radio" value="3" <?php echo ($result->online_papers_answer == '3'?'checked':''); ?>><?php echo e($result->choice3); ?><br>
                    <input type="radio" name="radio" value="4" <?php echo ($result->online_papers_answer == '4'?'checked':''); ?>><?php echo e($result->choice4); ?><br>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>   


        </div>
    </div>



    <!-- Modal -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/students/studentSurvay/show_online_result.blade.php ENDPATH**/ ?>