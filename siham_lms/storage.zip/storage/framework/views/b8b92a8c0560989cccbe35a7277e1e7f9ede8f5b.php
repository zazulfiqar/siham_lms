<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Header End -->

    <!-- Slider  Sectiion Start -->
    <div class="main_slider banner_section">
        <div class="carousel slide" data-ride="carousel" id="myCarousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                    <?php if($home_header_image == null): ?>
                    <img alt="img" src="<?php echo e(asset('images/banner.jpg')); ?>"> <?php endif; ?> <?php if($home_header_image != null): ?>
                    <img alt="img" src="<?php echo e(url('/siham_lms/storage/app/public/'.$home_header_image	)); ?>"> <?php endif; ?>

                    <div class="carousel-caption">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="slider_text">
                                        <div class="banner_text">

                                            <img src="<?php echo e(asset('images/logo_white.png')); ?>" alt="img" class="wow bounceInLeft" data-wow-delay="0.4s" data-wow-duration="2s">
                                            <h2 data-aos="fade-down">
                                                <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->banner_text); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <ul>

                                                    <li data-aos="fade-left" data-aos-delay="400">
                                                        <a href="<?php echo e(asset('/onlineClasses')); ?>">Live
                                                    Online Classes</a></li>
                                                    <li data-aos="fade-left" data-aos-delay="400"> <a href="<?php echo e(asset('/onlineTutor')); ?>">Find
                                                    Online Tutor</a></li>
                                                    <li data-aos="fade-left" data-aos-delay="400"><a href="<?php echo e(asset('course')); ?>">Join Us</a></li>
                                                </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Slider Sectiion End -->

    <!-- video-section -->
    <!-- video-section -->

    <!--startLearning-section -->
    <div class="startLearning_section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="startLearning_head wow bounceInDown" data-wow-delay="0.6s" data-wow-duration="2s">
                        <h2 data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->subjects_topic); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h2>
                        <p data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->subjects_text); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>

                    </div>
                </div>
            </div>
            <div class="tab-content">
                <div id="menu1" class="tab-pane fade in active">
                    <div class="row">
                        <div class="learning_slider">
                            <?php $__currentLoopData = $getRecordFrontHomeGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getRecordFrontHome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="fronttutor_box ">
                                    <div class="tutor_boxImg"><img src="<?php echo e(URL::asset('uploadsGalleryImage/'.$getRecordFrontHome->photo)); ?>" alt="img"></div>
                                    <div class="tutor_boxText">
                                        <h4> <?php echo e($getRecordFrontHome->name); ?></h4>

                                        <p><?php echo e($getRecordFrontHome->content); ?> </p>
                                    </div>
                                </div>
                            </div>
                            <!--
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="800">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(URL::asset('uploadsGalleryImage/'.$getRecordFrontHome->photo)); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="">
                                             <?php echo e($getRecordFrontHome->name); ?>

                                        </a>
                                        <h5><?php echo e($getRecordFrontHome->content); ?> </h5>
                                    </div>
                                </div>
                            </div> -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
                <div id="menu2" class="tab-pane fade">
                    <div class="row">
                        <div class="learning_slider">
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="800">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img2.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Algebra
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="700">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img1.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Calculus
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="600">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img4.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Trignometry
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="500">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img3.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Statistics
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="menu3" class="tab-pane fade">
                    <div class="row">
                        <div class="learning_slider">
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="800">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img1.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Chemistry<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="700">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img2.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Physics<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="600">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img3.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Accounting<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="500">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img4.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Finacce<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="menu4" class="tab-pane fade">
                    <div class="row">
                        <div class="learning_slider">
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="800">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img2.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">English<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="700">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img1.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">History<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="600">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img4.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Biology<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="500">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img3.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Zoology<img
                                            src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="menu5" class="tab-pane fade">
                    <div class="row">
                        <div class="learning_slider">
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="800">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img1.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Writing
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="700">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img2.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">French
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="600">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img3.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">Spanish
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="500">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img4.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">ESL
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="menu6" class="tab-pane fade">
                    <div class="row">
                        <div class="learning_slider">
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="800">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img2.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">ACT Test
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="700">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img1.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">SAT Prep
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="600">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img4.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">GRE
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="learnBox" data-aos="fade-up" data-aos-delay="500">
                                    <div class="learnBoxImg">
                                        <img src="<?php echo e(asset('images/learn_img3.png')); ?>" alt="img">
                                    </div>
                                    <div class="learnBoxText">
                                        <a data-fancybox="gallery" href="https://www.youtube.com/embed/nWwpyclIEu4">GMAT
                                        Tutors<img src="<?php echo e(asset('images/paly-icon.png')); ?>" alt="img"></a>
                                        <h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- startLearning-section -->


    <div class="clear"></div>


    <div class="Saying_section online_classes">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="startLearning_head">
                        <h2 data-aos="fade-down">Online Classes</h2>
                    </div>
                </div>
            </div>
            <div class="row">

                <?php $__currentLoopData = $home_page_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videosfront): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="video_box" data-aos="fade-up" data-aos-delay="300">
                        <div class="video_boxImg">
                            <img src="<?php echo e(URL::asset('uploadsVideoImage/'.$videosfront->photo)); ?>" alt="img">
                            <div class="video_boxImgOverlay">
                                <a data-fancybox="gallery" href="<?php echo e($videosfront->youtubeurl); ?>"><img src="images/paly-icon.png" alt="img"></a>
                            </div>
                        </div>
                        <div class="video_boxText">
                            <p><?php echo e($videosfront->content); ?></p>
                            <a class="btn_pink2"><?php echo e($videosfront->name); ?></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>

        </div>
    </div>



    <!-- WatchAnyTime-section -->

    <div class="WatchAnyTime_section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="startLearning_head">
                        <h2 data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_topic); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h2>
                        <p data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_text); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="WatchAnyTime_Box" data-aos="flip-left" data-aos-delay="300">
                        <img src="<?php echo e(asset('images/anyIcon_1.png')); ?>" alt="img">
                        <h4>
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_card_topic1); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h4>
                        <p>
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_card_text1); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="WatchAnyTime_Box" data-aos="flip-left" data-aos-delay="400">
                        <img src="<?php echo e(asset('images/anyIcon_2.png')); ?>" alt="img">
                        <h4>
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_card_topic2); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h4>
                        <p>
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_card_text2); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="WatchAnyTime_Box" data-aos="flip-left" data-aos-delay="500">
                        <img src="<?php echo e(asset('images/anyIcon_3.png')); ?>" alt="img">
                        <h4>
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_card_topic3); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h4>
                        <p>
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->learn_anywhere_card_text3); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12 center">
                    <div class="WatchAnyTime_btn" data-aos="flip-right" data-aos-delay="600">
                        <a href="<?php echo e(asset('register')); ?>" class="btn_pink">Join Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- WatchAnyTime-section -->

    <!-- Pricing-section -->
    <div class="Pricing_section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="startLearning_head">
                        <h2 data-aos="fade-down">Pricing</h2>
                        <p data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->pricing_content); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="row">

                        <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 col-sm-6 col-xs-12 priceDiv" data-aos="flip-left">
                            <div class="Pricing_Box">
                                <h3><?php echo e($price->course_duration); ?></h3>
                                <span><?php echo e($price->price); ?></span>
                                <p> <?php echo e($price->description); ?></p>
                                <hr>
                                <ul>
                                    <?php if($price->feature_one): ?>
                                    <li><?php echo e($price->feature_one); ?></li>
                                    <?php else: ?> <?php endif; ?> <?php if($price->feature_two): ?>
                                    <li><?php echo e($price->feature_two); ?></li>
                                    <?php else: ?> <?php endif; ?> <?php if($price->feature_three): ?>
                                    <li><?php echo e($price->feature_three); ?></li>
                                    <?php else: ?> <?php endif; ?> <?php if($price->feature_four): ?>
                                    <li><?php echo e($price->feature_four); ?></li>
                                    <?php else: ?> <?php endif; ?> <?php if($price->feature_five): ?>
                                    <li><?php echo e($price->feature_five); ?></li>
                                    <?php else: ?> <?php endif; ?>
                                </ul>
                            </div>
                            <div class="Pricing_Box2">
                                <a href="<?php echo e(asset('register')); ?>" class="btn_pink">Join Us</a>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Pricing-section -->

    <!-- Saying-section -->
    <div class="Saying_section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="startLearning_head">
                        <h2 data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->testimonials); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="Saying_slider" data-aos="zoom-out-left" data-aos-delay="300">

                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="Saying_box">
                            <img src="<?php echo e(url('/siham_lms/storage/app/public/'.$testimonial->image)); ?>">
                            <!--<img src="<?php echo e(url(''.$testimonial->image)); ?>">-->
                            
                            <h4><?php echo e($testimonial->name); ?></h4>
                            
                            <p><?php echo e($testimonial->description); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </div>
    </div>
    <!-- Saying-section -->

    <!-- Blog-section -->
    <div class="Blog_section">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-sm-10 col-xs-12 center">
                    <div class="startLearning_head">
                        <h2 data-aos="fade-down">Blog</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="Blog_slider" data-aos="zoom-out-right" data-aos-delay="300">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="blog_Box wow bounceIn" data-wow-delay="0.2s" data-wow-duration="2s">
                            <p> <?php echo e(\Illuminate\Support\Str::limit($blog->description, 300, $end='...')); ?> </p>
                            <!--<p><?php echo e($blog->description); ?></p>-->
                            <a href="<?php echo e(route('blogdetail', Qs::hash($blog->id))); ?>" class="dropdown-item"><i class="icon-checkbox-checked2"></i> Read more</a>
                            <div class="blog_BoxOverlay">
                                <p>
                                    <?php echo e(\Illuminate\Support\Str::limit($blog->title, 70, $end='...')); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- Blog-section -->

    <!-- faq-section -->
    <div class="faq_section">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-sm-9 col-xs-12 center">
                    <div class="startLearning_head">
                        <h2 data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->faq_topic); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h2>
                        <p data-aos="fade-down">
                            <?php $__currentLoopData = $frontDynamic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frontDynami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($frontDynami->faq_content); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </h2>
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9 col-sm-9 col-xs-12 center">
                    <div class="faq_text">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">


                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="panel panel-default" data-aos="zoom-in" data-aos-delay="300">
                                <div class="panel-heading" role="tab" id="headingOne">
                                    <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($index+1); ?>" aria-expanded="true" aria-controls="collapseOne">
                                            <?php echo e($faq->faq); ?>?
                                        </a>
                                    </h4>
                                </div>
                                <div id="<?php echo e($index+1); ?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                    <div class="panel-body">
                                        <?php echo e($faq->description); ?>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- faq-section -->


    <!--Footer Content Start-->
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/frontend/index.blade.php ENDPATH**/ ?>