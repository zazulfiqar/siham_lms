
<?php $__env->startSection('page_title', 'Manage Courses'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Manage Courses</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#new-course" class="nav-link active" data-toggle="tab">Add Course</a>
                </li>

                <li class="nav-item"><a href="#manage-course" class="nav-link" data-toggle="tab">Manage Course</a>
                </li>

                
                
                
                
                
                

                
                
                
            </ul>
            <div class="tab-content">
                <div class="tab-pane show  active fade" id="new-course">
                    <div class="row">
                        <div class="col-md-6">
                            
                            <form class="" method="post" action="<?php echo e(route('courses.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>

                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Course Name
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="name" name="name" value="<?php echo e(old('name')); ?>" required type="text"
                                               class="form-control" placeholder="Name of Course">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Course Code
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="code" name="code" value="<?php echo e(old('code')); ?>" required type="text"
                                               class="form-control" placeholder="Course Code">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Course
                                        Description <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="description" name="description" value="<?php echo e(old('description')); ?>"
                                               required type="text" class="form-control"
                                               placeholder="Course Description">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="my_class_id" class="col-lg-3 col-form-label font-weight-semibold">Select
                                        Class <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select required data-placeholder="Select Class" class="form-control select"
                                                name="my_class_id" id="my_class_id">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $my_classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    <?php echo e(old('my_class_id') == $c->id ? 'selected' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">

                                    <label for="teacher_id" class="col-lg-3 col-form-label font-weight-semibold">Teacher
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <select required data-placeholder="Select Teacher"
                                                class="form-control select-search" name="teacher_id" id="teacher_id">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    <?php echo e(old('teacher_id') == Qs::hash($t->id) ? 'selected' : ''); ?> value="<?php echo e(Qs::hash($t->id)); ?>"><?php echo e($t->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="name" class="col-lg-3 col-form-label font-weight-semibold">Time Slot
                                        <span class="text-danger">*</span></label>
                                    <div class="col-lg-9">
                                        <input id="time_slot" name="time_slot" value="<?php echo e(old('time_slot')); ?>" required
                                               type="text" class="form-control" placeholder="Time Slot">
                                    </div>
                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Submit form <i
                                            class="icon-paperplane ml-2"></i></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                
                <div class="tab-pane fade" id="manage-course">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Course Name</th>

                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($c->name); ?> </td>

                                <td><?php echo e($c->description); ?> </td>

                                <td class="text-center">
                                    <div class="list-icons">
                                        <div class="dropdown">
                                            <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                <i class="icon-menu9"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-left">
                                                
                                                <?php if(Qs::userIsTeamSA()): ?>
                                                <a href="<?php echo e(route('courses.edit', $c->id)); ?>"
                                                class="dropdown-item"><i class="icon-pencil"></i> Edit</a>
                                                <a id="<?php echo e($c->id); ?>" onclick="confirmDelete(this.id)" href="#"
                                                class="dropdown-item"><i class="icon-trash"></i> Delete</a>
                                                
                                                <a href="<?php echo e('students/addtopic?id='.$c->id); ?>" class="dropdown-item"><i class="icon-trash"></i> Add Topic</a>
                                                
                                                
                                                
                                                
                                                <form method="post" id="item-delete-<?php echo e($c->id); ?>"
                                                action="<?php echo e(route('courses.destroy', $c->id)); ?>"
                                                class="hidden"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?></form>
                                                <?php endif; ?>
                                                
                                                <!--<?php if(Qs::userIsSuperAdmin()): ?>-->
                                                <!--    <a id="<?php echo e($c->id); ?>" onclick="confirmDelete(this.id)" href="#"-->
                                                <!--       class="dropdown-item"><i class="icon-trash"></i> Delete</a>-->
                                                <!--    <form method="post" id="item-delete-<?php echo e($c->id); ?>"-->
                                                <!--          action="<?php echo e(route('courses.destroy', $c->id)); ?>"-->
                                                <!--          class="hidden"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?></form>-->
                                                <!--<?php endif; ?>-->
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/courses/index.blade.php ENDPATH**/ ?>