<head>
    <meta charset="utf-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <title>::: Space e - Learning Service :::</title>
    <!-- All CSS inclueded in one  -->
    <link href="<?php echo e(asset('css/allmix.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/slicknav.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>
<?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/frontend/layout/head.blade.php ENDPATH**/ ?>