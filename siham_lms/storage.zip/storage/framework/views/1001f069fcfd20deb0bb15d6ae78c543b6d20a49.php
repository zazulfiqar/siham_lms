<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Survey List</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
            </ul>
            <form  method="post" enctype="multipart/form-data" class="wizard-form steps-validation" action="<?php echo e(route('students.surveyStore')); ?> "  data-fouc>
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <?php $count=1; ?>
                <form action="<?php echo e(route('students.surveyStore')); ?> "  method="POST">
                    <?php echo e(csrf_field()); ?>

                <?php
                 $count=1;
                ;?>

                <div class="wrapper bg-white rounded">
                    <div class="content">
                        <?php $__currentLoopData = $survay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="studentId" value="<?php echo e(Auth::user()->id); ?>">
                        <input type="hidden" name="question_id[<?php echo e($count); ?>]" value="<?php echo e($sur->id); ?>">

                        <p class="text-justify h5 pb-2 font-weight-bold"> <?php echo e($loop->iteration); ?> <?php echo e($sur->question); ?> </p>
                        <div class="options py-3">
                            <label class="rounded p-2 option"> Excellent
                                 <input required type="radio"  name="answer[<?php echo e($count); ?>]" value="Excellent">
                                <span class="crossmark"></span>
                            </label>

                            <label class="rounded p-2 option"> Good
                                <input required type="radio" name="answer[<?php echo e($count); ?>]" value="Good">
                                <span class="checkmark"></span>
                            </label>

                            <label class="rounded p-2 option"> Average
                                <input required type="radio" name="answer[<?php echo e($count); ?>]" value="Average">
                            </label>
                            <?php $count++; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if(!$survay->isEmpty()): ?>
                    <input type="submit" class="btn btn-primary" value="Submit form">
                    <?php else: ?>
                    Empty Survey List
                    <?php endif; ?>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/students/studentSurvay/index.blade.php ENDPATH**/ ?>