<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header header-elements-inline">

            <?php echo Qs::getPanelOptions(); ?>

        </div>




        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form class="" method="post" action="<?php echo e(route('std_ins.update', $instructions->id)); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold">Title <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="title" value="<?php echo e($instructions->title); ?>" required type="text" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold">Details <span class="text-danger">*</span></label>
                            <div class="col-lg-9">
                                <input name="details" value="<?php echo e($instructions->details); ?>" required type="text" class="form-control" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label font-weight-semibold">Status<span
                                    class="text-danger">*</span></label>
                            <div class="col-lg-9 form-control">
                                <select name="status" id="status" class="form-control">
                                    <option value="active">Active</option>
                                    <option value="inactive">InActive</option>
                                </select>
                            </div>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary">Submit form <i class="icon-paperplane ml-2"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>




    </div>

    subject Edit Ends

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/SATSPanel/studentsInstructions/edit.blade.php ENDPATH**/ ?>