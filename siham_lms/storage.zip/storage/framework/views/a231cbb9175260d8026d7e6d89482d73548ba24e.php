<?php $__env->startSection('page_title', 'Manage Paper'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Result </h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">

            <div class="tab-content">


                <div class="" id="">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Course</th>
                            <th>Topic</th>

                            <th>Description</th>
                            <th>Paper Id</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>
                                <?php if(isset($paper->courses->name)): ?>
                                <td><?php echo e($paper->courses->name); ?></td>
                                <?php else: ?>
                                    <td>Not Assign</td>
                                <?php endif; ?>
                                <td><?php echo e($paper->topic); ?></td>
                                <td><?php echo e($paper->description); ?></td>

                                <td><?php echo e($paper->unique_id); ?></td>


                                <td class="text-center">
                                    <div class="list-icons">
                                        <a href="<?php echo e('resultbypaper?id='.$paper->id); ?>" class="btn btn-primary">Result</a>
                                        
                                        

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>


        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/pages/support_team/papers/resultlist.blade.php ENDPATH**/ ?>