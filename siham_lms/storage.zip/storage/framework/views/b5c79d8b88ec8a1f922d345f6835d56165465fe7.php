
<?php $__env->startSection('page_title', 'Uploaded Lectures Here by Teacher'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Uploaded Lectures</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
                <li class="nav-item"><a href="#manage-course" class="nav-link" data-toggle="tab">All Learnng Material</a>
                </li>

            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="manage-course">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Course Name</th>
                            <th>Topic</th>
                            <th>Description</th>
                            <th>file</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>

                                <td><?php echo e($lecture->course_id); ?></td>
                                <td><?php echo e($lecture->topic); ?></td>
                                <td><?php echo e($lecture->description); ?></td>
                                <?php if($lecture->file): ?>
                                <td><a href="<?php echo e(asset('siham_lms/storage/app/public/'.$lecture->file)); ?>" target="_blank">Download
                                        file</a></td>
                                <?php else: ?>
                                    <td>No file</td>
                                <?php endif; ?>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/lectures/std_lecture.blade.php ENDPATH**/ ?>