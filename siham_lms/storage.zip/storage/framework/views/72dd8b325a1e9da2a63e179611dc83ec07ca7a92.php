
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h6 class="card-title">Inactive Students List</h6>
            <?php echo Qs::getPanelOptions(); ?>

        </div>
        <div class="card-body">
            <ul class="nav nav-tabs nav-tabs-highlight">
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="all-students">
                    <table class="table datatable-button-html5-columns">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $inactiveTeachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teachers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img class="rounded-circle" style="height: 40px; width: 40px;"
                                         src="<?php echo e(url('/siham_lms/storage/app/public/'.$teachers->photo	)); ?>" alt="photo"></td>
                                <td><?php echo e($teachers->name); ?></td>
                                <td><?php echo e($teachers->username); ?></td>
                                <td><?php echo e($teachers->email); ?></td>
                                <td class="text-center">
                                    <div class="list-icons">
                                        <div class="dropdown">
                                            <a href="#" class="list-icons-item" data-toggle="dropdown">
                                                <i class="icon-menu9"></i>
                                            </a>
                                            
                                            <div class="dropdown-menu dropdown-menu-left">
                                                
                                                   <?php if(isset($teachers->teacher_record->id)): ?>
                                                <a href="<?php echo e(route('students.show',
                                                Qs::hash($teachers->teacher_record->id))); ?>"
                                                   class="dropdown-item"><i class="icon-eye"></i> View Profile</a>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('teacher.active', Qs::hash($teachers->id))); ?>"
                                                   class="dropdown-item"><i class="icon-checkbox-checked2"></i> Active</a>
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/pages/support_team/teachers/inactiveTeachers.blade.php ENDPATH**/ ?>