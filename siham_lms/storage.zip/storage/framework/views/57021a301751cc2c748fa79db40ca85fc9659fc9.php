<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="innerpages body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Header End -->
    <!-- innerBanner start -->
    <div class="innerBanner">
        <?php if($contact_header_image == null): ?>
            <img src="<?php echo e(asset('images/Bannar-4.jpg')); ?>" class="img-responsive" alt="courses-Banner">
        <?php endif; ?>
        <?php if($contact_header_image != null): ?>
        <img src="<?php echo e(url('/siham_lms/storage/app/public/'.$contact_header_image	)); ?>"  class="img-responsive" alt="courses-Banner">


        <?php endif; ?>


      <div class="innerBannerOverlay">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12 centerCol">
            <h1>Contact Us</h1>
          </div>
        </div>
      </div>
    </div>
    <!-- innerBanner end -->
    <div class="clear"></div>
    <!--startLearning-section -->
    <div class="contact_map">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26360909.888257876!2d-113.74875964478716!3d36.242299409623534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited%20States!5e0!3m2!1sen!2s!4v1613574161212!5m2!1sen!2s"></iframe>
    </div>
    <div class="contact_page">
      <div class="container">
        <div class="row">
          <div class="contact_inner">
            <div class="col-md-8 col-sm-8 col-xs-12">
              <div class="contact_pageForm">
                <div class="row">
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <label><span>*</span> Name</label>
                    <input type="text">
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <label><span>*</span> Email</label>
                    <input type="email">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <label>Company Name</label>
                    <input type="text">
                  </div>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <label> Website</label>
                    <input type="url">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <label><span>*</span> Your Messsage</label>
                    <textarea></textarea>
                    <input type="submit" value="Send messsage">
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="contact_info">
                <div class="contact_head">
                  <h2>Contact Info</h2>
                </div>



                <div class="contact_infoBox">
                  <div class="contact_infoBoxIcon">
                    <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
                  </div>
                  <div class="contact_infoBoxText">
                    <?php $__currentLoopData = $contactsAddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactsAddres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4><?php echo e($contactsAddres->type); ?></h4>
                     <p><?php echo e($contactsAddres->description); ?></p>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="contact_infoBox">
                  <div class="contact_infoBoxIcon">
                    <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                  </div>
                  <div class="contact_infoBoxText">
                    <?php $__currentLoopData = $contactsPhone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactsPhon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4><?php echo e($contactsPhon->type); ?></h4>
                     <p><?php echo e($contactsPhon->description); ?></p>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="contact_infoBox">
                  <div class="contact_infoBoxIcon">
                    <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                  </div>
                  <div class="contact_infoBoxText">
                    <?php $__currentLoopData = $contactsEmail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contactsEmail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4><?php echo e($contactsEmail->type); ?></h4>
                     <p><?php echo e($contactsEmail->description); ?></p>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                  <div class="clearfix"></div>
                  <div class="contact_infoBox">
                      <div class="contact_infoBoxIcon">
                          <span><i class="fa fa-dribbble" aria-hidden="true"></i></span>
                      </div>
                      <div class="contact_infoBoxText">
                          <h4>website</h4>
                          <p>.com</p>
                      </div>
                  </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- startLearning-section -->

    <!--Footer Content Start-->
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\siham_lms\resources\views/frontend/contact.blade.php ENDPATH**/ ?>