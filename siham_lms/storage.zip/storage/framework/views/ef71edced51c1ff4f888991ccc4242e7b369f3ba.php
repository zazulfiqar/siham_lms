<!DOCTYPE html>
<html lang="zxx">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body class="innerpages body_bg">
    <!-- Header Start -->
    <?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Header End -->

<!-- innerBanner start -->
		<div class="innerBanner">
                <?php if($price_header_image == null): ?>
                <img src="<?php echo e(asset('images/Bannar-5.jpg')); ?>" class="img-responsive" alt="courses-Banner">
            <?php endif; ?>
            <?php if($price_header_image != null): ?>
                
                <img src="<?php echo e(url('/siham_lms/storage/app/public/'.$price_header_image	)); ?>"  class="img-responsive" alt="courses-Banner">

            <?php endif; ?>

			<div class="innerBannerOverlay">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 centerCol">
						<h1>Pricing</h1>
					</div>
				</div>
			</div>
		</div>
<!-- innerBanner end -->

   <div class="clear"></div>

  <!-- Pricing-section -->
    <div class="Pricing_section Pricing_page">
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-sm-10 col-xs-12 center">
            <div class="startLearning_head">
              <h2 data-aos="fade-down">Pricing</h2>
              <p data-aos="fade-down">Get access to specialized video training that teaches practical skills for improving your career and life, every month. Weekly content updates from multiple world's best experts.</p>
            </div>
          </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-4 col-xs-12" data-aos="flip-left">
                <div class="Pricing_Box">
                    <h3><?php echo e($price->course_duration); ?></h3>
                    <span><?php echo e($price->price); ?></span>
                    <p><?php echo e($price->description); ?></p>
                    <hr>
                    <ul>
                        <?php if($price->feature_one): ?>
                        <li><?php echo e($price->feature_one); ?></li>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php if($price->feature_two): ?>
                        <li><?php echo e($price->feature_two); ?></li>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php if($price->feature_three): ?>
                        <li><?php echo e($price->feature_three); ?></li>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php if($price->feature_four): ?>
                        <li><?php echo e($price->feature_four); ?></li>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php if($price->feature_five): ?>
                        <li><?php echo e($price->feature_five); ?></li>
                        <?php else: ?>
                        <?php endif; ?>

                    </ul>
                </div>
                <div class="Pricing_Box2">
                <a href="<?php echo e(route('register')); ?>" class="btn_pink">Join Us</a>
                </div>
            </div>


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <!-- Pricing-section -->

<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Js Files Start -->
    <script src="<?php echo e(asset('js/allmix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('js/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
  </body>
</html>
<?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/frontend/pricing.blade.php ENDPATH**/ ?>