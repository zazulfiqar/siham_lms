


    <link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('global_assets/css/icons/icomoon/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link href=" <?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href=" <?php echo e(asset('assets/css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href=" <?php echo e(asset('assets/css/layout.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href=" <?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href=" <?php echo e(asset('assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->


<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.min.css')); ?>" type="text/css">


<link href=" <?php echo e(asset('assets/css/qs.css')); ?>" rel="stylesheet" type="text/css">


    <script src="<?php echo e(asset('global_assets/js/main/jquery.min.js')); ?> "></script>
    <script src="<?php echo e(asset('global_assets/js/main/bootstrap.bundle.min.js')); ?> "></script>
    <script src="<?php echo e(asset('global_assets/js/plugins/loaders/blockui.min.js')); ?> "></script>
<?php /**PATH /home/clientdemolink/spaceelearn.com/siham_lms/resources/views/partials/inc_top.blade.php ENDPATH**/ ?>